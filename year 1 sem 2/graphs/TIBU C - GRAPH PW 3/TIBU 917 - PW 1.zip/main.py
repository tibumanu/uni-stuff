from ui import *

if __name__ == "__main__":
    ui = UI()
    ui.startMenu()