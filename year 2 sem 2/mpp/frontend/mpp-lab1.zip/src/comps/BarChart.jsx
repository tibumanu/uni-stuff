import React, { useRef, useEffect } from 'react';
import Chart from 'chart.js/auto';

const BarChart = ({ elements }) => {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    const ctx = chartRef.current.getContext('2d');

    // destroy previous chart instance if it exists; would error
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    // group elements by gravity
    const groupedData = elements.reduce((acc, element) => {
      const { gravity } = element;
      if (!acc[gravity]) {
        acc[gravity] = 1;
      } else {
        acc[gravity]++;
      }
      return acc;
    }, {});

    // extract labels and counts for chart data
    const labels = Object.keys(groupedData);
    const counts = Object.values(groupedData);

    // create new chart instance
    chartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Element Count by Gravity',
          data: counts,
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Count'
            }
          },
          x: {
            title: {
              display: true,
              text: 'Gravity'
            }
          }
        }
      }
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [elements]);

  return (
    <div>
      <h2>Bar Chart</h2>
      <canvas ref={chartRef} />
    </div>
  );
};

export default BarChart;
