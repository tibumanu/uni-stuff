import { useState } from "react";
import { IElement } from "./Element.type";
import "./ElementList.style.css";
import ElementModal from "./ElementModal";


type Props = {
    list: IElement[];
    onDeleteClickHandle: (data: IElement) => void;
    onEdit: (data: IElement) => void;
}

export const ElementList = (props: Props) => {

    const { list, onDeleteClickHandle, onEdit } = props;

    const [showModal, setShowModal] = useState(false);
    const [dataToShow, setDataToShow] = useState(null as IElement | null);
    
    const viewElement = (data: IElement) => {
      console.log(data);
     setDataToShow(data);
      setShowModal(true);
    }

    const testFunction = () => {
        console.log("test");
    }

    const onCloseModal = () => {
        setShowModal(false);
    }

    return (
        <div>
        <table>
          <tr>
            <th>ID</th>
            <th>TITLE</th>
            <th>DESCRIPTION</th>
            <th>GRAVITY</th>
            <th>Action</th>
          </tr>
          {list.map((el) => {
          return(
          <tr key={el.id}>
            <td>{`${el.id}`}</td>
            <td>{`${el.title}`}</td>
            <td>{`${el.desc}`}</td>
            <td>{`${el.gravity}`}</td>
            <div>
                <input type="button" value="View" onClick={() => viewElement(el)}/>
                <input type="button" value="Edit" onClick={() => onEdit(el)}/>
                <input type="button" value="Delete" onClick={() => onDeleteClickHandle(el)}/>
            </div>
          </tr>
          )
          })}
        </table>
        {showModal && dataToShow !== null && (<ElementModal onClose={onCloseModal} data={dataToShow}/>)}
        </div>
        )
};

export default ElementList;