import "./ElementModal.style.css";
import { IElement } from "./Element.type";

type Props = {
    onClose: () => void;
    data: IElement
}

const ElementModal = (props: Props) => {

    const { onClose } = props;

    return( 
    <div id="myModal" className="modal">
    <div className="modal-content">
      <span className="close" onClick={onClose}>&times;</span>
        <div>
            <h3>ELEMENT DATA</h3>
            <div>
                <label>ID:</label>
                <span>{props.data.id}</span>
            </div>
            <div>
                <label>TITLE:</label>
                <span>{props.data.title}</span>
                </div>
            <div>
                <label>DESC:</label>
                <span>{props.data.desc}</span>
            </div>
            <div>
                <label>GRAVITY:</label>
                <span>{props.data.gravity}</span>
            </div>
        </div>
    </div>
  
  </div>
    )
};

export default ElementModal;