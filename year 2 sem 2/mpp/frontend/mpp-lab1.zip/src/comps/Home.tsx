import { useState } from "react";
import { IElement, PageEnum, dummyElementList } from "./Element.type";
import "./Home.style.css"
import {ElementList} from "./ElementList";
import AddElement from "./AddElement";
import EditElement from "./EditElement";
import { sortAscByGravity, sortAscByTitle, sortDescByGravity, sortDescByTitle } from "./Features";
import BarChart from "./BarChart";


const Home = () => {

    const [elementList, setElementList] = useState(dummyElementList as IElement[])

    const [shownPage, setShownPage] = useState(PageEnum.list)
    const [datatoEdit, setDataToEdit] = useState({id:"", title:"", desc:"", gravity:1} as unknown as IElement);
    const [selectedSortOption, setSelectedSortOption] = useState("");
    const [chartjs, setChartjs] = useState();



    const onAddElementClickHandler = () => {
        setShownPage(PageEnum.add);
    }

    const showListPage = () => {
        setShownPage(PageEnum.list);
    }

    const addE = (data: IElement) => {
        setElementList([...elementList, data]);
        showListPage();
    }

    const deleteElement = (data: IElement) => {
        setElementList(elementList.filter((el) => el.id !== data.id));
    }

    const editElementData = (data: IElement) => {
        setShownPage(PageEnum.edit);
        setDataToEdit(data);
    }

    const updateData = (data: IElement) => {
        const updatedData = elementList.map((el) => {
            if(el.id === data.id){
                return data;
            }
            return el;
        });
        setElementList(updatedData);
        showListPage();
    }

    const handleSortOptionChanged = (e:any) => {
        const selectedOption = e.target.value;
        setSelectedSortOption(selectedOption);

        let sortedList : IElement[] = [];

        switch (selectedOption){
            case "alphabetically-decrease":
                sortedList = sortDescByTitle({elementList});
                break;
            case "alphabetically-increase":
                sortedList = sortAscByTitle({elementList});
                break;
            case "gravity-increase":
                sortedList = sortAscByGravity({elementList});
                break;
            case "gravity-decrease":
                sortedList = sortDescByGravity({elementList});
                break;
            default:
                sortedList = elementList;
                break;
        }
        setElementList(sortedList);
    }

   

    return (
        <body>
        <article className="article-header">
            <header>
                React CRUD
            </header>
        </article>
    
        <section className="section-content">
            {shownPage === PageEnum.list && 
            <>
            <input type="button" value="ADD ELEMENT" 
            onClick={onAddElementClickHandler}/>
            <select className="sort-options" id="sort-options" data-testid="sort-options" onChange={handleSortOptionChanged}>
                    <option value="sort-by">Sort By</option>
                    <option value="alphabetically-increase">Title ↑</option>
                    <option value="alphabetically-decrease">Title ↓</option>
                    <option value="gravity-increase">Gravity ↑</option>
                    <option value="gravity-decrease">Gravity ↓</option>
                </select>
            <ElementList list={elementList}
                
                onDeleteClickHandle={deleteElement}    
                onEdit={editElementData}
                />
            </>
            }
            {shownPage === PageEnum.add && (<AddElement onBackButtonClickHandle={showListPage} onSubmitClickHandle={addE}/>)}

            {shownPage === PageEnum.edit && <EditElement data={datatoEdit} onBackButtonClickHandle={showListPage} onUpdateClickHandle={updateData}/>}
            <BarChart elements={elementList} />

        </section>
        </body>
        
    );
    }

export default Home;